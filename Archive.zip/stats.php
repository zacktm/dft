<?




$getjson = file_get_contents('https://api.coinmarketcap.com/v1/ticker/draftcoin');


echo $getjson
    
    
    ?>